#include <vector>
#include <thread>
#include <iostream>

void f(int i, int j, int k) {
	std::cout << i <<"\n";
}

std::vector<std::thread> threads;

int main() {
	//std::thread t1(f, 1);
//	std::thread t2(f ,2);
	threads.push_back((std::thread(f,1,2,3)));
	threads.push_back((std::thread(f,2,3,4)));
	threads[0].join();
	threads[1].join();
	return 0;
}
