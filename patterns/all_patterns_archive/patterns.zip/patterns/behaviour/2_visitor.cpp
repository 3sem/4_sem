#include <iostream>

class Element;

class Visitor {
	public:
	void visit(Element &el);// {
		//std::cout << el->field << std::endl;
	//}

};

class Element {
	public:
		int field;
		void accept(Visitor &v) {v.visit(*this);};
};

void Visitor::visit(Element &el) {
	std::cout << el.field << std::endl;
}

int main() {
	Element el1;
	el1.field = 12345;
	Visitor v;
	el1.accept(v);

	return 0;
}
