#include <iostream>
using namespace std;

class Stack {
	friend class StackIter;
	int sp;
	int data[100];
	public:
	Stack() {
		sp = 0;
	}

	void push(int v) {
		data[sp] = v;
		sp++;
	}
	int pop() {
		if (sp == 0)
			return data[sp];
		else {
			sp --;
			return data[sp + 1];
		}
	}

};

class StackIter {
	const Stack& stack;
	int index;
public:
	StackIter(const Stack &stk):stack(stk) {
		index = 0;
	}

	void operator++() {
		index++;
	}
	int show() {
		if (index >= stack.sp)
			return stack.data[stack.sp - 1];
		return stack.data[index];
	}
};


int main() {
	Stack s;
	s.push(1);
	s.push(2);
	s.push(3);
	StackIter si(s);
	int i = 0;
	while(i < 4) {
		cout << si.show() << endl;
		++si;
		i++;
	}

	return 0;
}
